puts "Webcamp".reverse
