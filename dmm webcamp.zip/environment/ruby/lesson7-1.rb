puts "計算をはじめます"
puts "2つの値を入力してください"

a = gets.to_i
b = gets.to_i

puts "計算結果を出力します"
puts "a*b = #{a * b} "
puts "計算を終了します"