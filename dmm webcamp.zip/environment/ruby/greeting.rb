def greeting(name)
  return "Hello, #{name}!"
  "Good morting,#{name}!"
end

puts greeting('John')